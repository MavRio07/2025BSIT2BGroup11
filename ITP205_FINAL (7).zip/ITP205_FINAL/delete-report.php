<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/data_functions.php';
require_once 'includes/csrf.php'; 

if (!isLoggedIn()) {
    $_SESSION['flash'] = "Please log in to perform this action.";
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (!validateCSRFToken($csrfToken)) {
        $_SESSION['flash'] = "Security error: Invalid token.";
        header("Location: history-report.php");
        exit;
    }

    $alertIdToDelete = $_POST['alert_id'] ?? '';
    $current_user_email = getUserEmail(); 

    if (!$alertIdToDelete) {
        $_SESSION['flash'] = "Error: Missing alert ID.";
        header("Location: history-report.php");
        exit;
    }
    
    $alerts = loadAlerts();
    $is_user_alert = false;
    
    foreach ($alerts as $alert) {
        if (isset($alert['id']) && $alert['id'] === $alertIdToDelete && 
            isset($alert['user_email']) && $alert['user_email'] === $current_user_email) {
            $is_user_alert = true;
            break;
        }
    }

    if ($is_user_alert) {
        if (deleteAlert($alertIdToDelete)) {
            $_SESSION['flash'] = "Alert deleted successfully.";
        } else {
            $_SESSION['flash'] = "Error: Could not delete the alert.";
        }
    } else {
        $_SESSION['flash'] = "Access Denied: You can only delete your own alerts.";
    }

    header("Location: history-report.php"); 
    exit;
} else {
    header("Location: history-report.php");
    exit;
}
?>