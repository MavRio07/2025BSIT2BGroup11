<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/data_functions.php';
require_once 'includes/csrf.php'; 

if (!isLoggedIn()) {
    $_SESSION['flash'] = "Please log in to update a report.";
    header("Location: index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: history-report.php");
    exit;
}

$csrfToken = $_POST['csrf_token'] ?? '';
if (!validateCSRFToken($csrfToken)) {
    $_SESSION['flash'] = "Security error: Invalid token.";
    header("Location: history-report.php");
    exit;
}

$report_id = filter_input(INPUT_POST, 'report_id', FILTER_SANITIZE_SPECIAL_CHARS);
$new_urgency = filter_input(INPUT_POST, 'urgency', FILTER_SANITIZE_SPECIAL_CHARS);
$new_message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING); 

$current_user_email = getUserEmail();

if (!$report_id || !$new_urgency || !$new_message) {
    $_SESSION['flash'] = "Error: All required fields must be filled out.";
    header("Location: history-report.php");
    exit;
}

if (updateAlert($report_id, $new_urgency, $new_message, $current_user_email)) {
    $_SESSION['flash'] = "Your report has been **successfully updated**!";
} else {
    $_SESSION['flash'] = "Error: The report could not be updated or you do not have permission.";
}

header("Location: history-report.php");
exit;
?>