<?php
require_once 'includes/config.php';
require_once 'includes/data_functions.php';
require_once 'includes/csrf.php';

if (!isLoggedIn()) {
    $_SESSION['show_login_modal'] = true;
    header("Location: index.php");
    exit();
}

$current_user_email = getUserEmail();

$all_alerts = loadAlerts();
$user_reports = array_filter($all_alerts, function($alert) use ($current_user_email) {
    return isset($alert['user_email']) && $alert['user_email'] === $current_user_email;
});
$reports_data = array_values($user_reports);

include 'includes/header.php';
?>

<div class="section">
    <h1 class="page-title">Your Report History</h1>

    <?php if (isset($_SESSION['flash'])): ?>
        <div class="success-message">
            <?php echo htmlspecialchars($_SESSION['flash']); unset($_SESSION['flash']); ?>
        </div>
    <?php endif; ?>

    <div class="alerts-container">
        <?php if (empty($reports_data)): ?>
            <div class="no-alerts">
                You have not submitted any alerts yet.
            </div>
        <?php else: ?>
            <?php foreach ($reports_data as $alert): ?>
                <div class="alert-card urgency-<?php echo strtolower($alert['urgency'] ?? 'low'); ?> status-<?php echo strtolower($alert['status'] ?? 'pending'); ?>">
                    <div class="alert-header">
                        <div class="alert-urgency">
                            <span class="urgency-badge urgency-<?php echo strtolower($alert['urgency'] ?? 'low'); ?>">
                                <?php echo strtoupper($alert['urgency'] ?? 'LOW'); ?>
                            </span>
                            <span class="status-badge status-<?php echo strtolower($alert['status'] ?? 'pending'); ?>">
                                <?php echo ucfirst($alert['status'] ?? 'Pending'); ?>
                            </span>
                        </div>
                        <div class="alert-time">
                            <?php echo htmlspecialchars($alert['timestamp'] ?? 'N/A'); ?>
                        </div>
                    </div>

                    <div class="alert-body">
                        <div class="alert-info">
                            <strong>Message:</strong>
                            <p><?php echo nl2br(htmlspecialchars($alert['message'])); ?></p>
                        </div>
                    </div>

                    <div class="alert-actions">
                        <form action="update-report.php" method="POST" class="status-update-form">
                            <?php echo getCSRFTokenField(); ?>
                            <input type="hidden" name="report_id" value="<?php echo htmlspecialchars($alert['id']); ?>">
                            <label for="status_<?php echo $alert['id']; ?>">Update Status:</label>
                            <select name="status" id="status_<?php echo $alert['id']; ?>">
                                <option value="pending" <?php if (($alert['status'] ?? '') === 'pending') echo 'selected'; ?>>Pending</option>
                                <option value="reviewing" <?php if (($alert['status'] ?? '') === 'reviewing') echo 'selected'; ?>>Reviewing</option>
                                <option value="resolved" <?php if (($alert['status'] ?? '') === 'resolved') echo 'selected'; ?>>Resolved</option>
                                <option value="closed" <?php if (($alert['status'] ?? '') === 'closed') echo 'selected'; ?>>Closed</option>
                            </select>
                            <button type="submit" class="update-btn">Update</button>
                        </form>

                        <form action="delete-report.php" method="POST" class="delete-form" onsubmit="return confirm('Are you sure you want to delete this alert?');">
                            <?php echo getCSRFTokenField(); ?>
                            <input type="hidden" name="alert_id" value="<?php echo htmlspecialchars($alert['id']); ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <a href="help.php" class="btn-back">Submit New Alert</a>
</div>

<style>
.section { margin: 2rem; font-family: Arial, sans-serif; }

.success-message { background: #d4edda; color: #155724; padding: 1rem; border-radius: 6px; margin-bottom: 1.5rem; }

.alerts-container { display: flex; flex-direction: column; gap: 1.5rem; }

.alert-card { background: white; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); padding: 1.5rem; border-left: 5px solid #667eea; }

.alert-card.urgency-critical { border-left-color: #dc3545; background: #fff5f5; }
.alert-card.urgency-high { border-left-color: #ff6b6b; }
.alert-card.urgency-medium { border-left-color: #ffc107; }
.alert-card.urgency-low { border-left-color: #28a745; }

.alert-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; border-bottom: 1px solid #eee; padding-bottom: 1rem; }
.alert-urgency { display: flex; gap: 0.5rem; }
.urgency-badge { padding: 0.35rem 0.75rem; border-radius: 12px; font-size: 0.75rem; font-weight: bold; color: white; }
.urgency-critical { background: #dc3545; }
.urgency-high { background: #ff6b6b; }
.urgency-medium { background: #ffc107; color: #333; }
.urgency-low { background: #28a745; }

.status-badge { padding: 0.35rem 0.75rem; border-radius: 12px; font-size: 0.75rem; font-weight: bold; }
.status-pending { background: #ffc107; color: #333; }
.status-reviewing { background: #17a2b8; color: white; }
.status-resolved { background: #28a745; color: white; }
.status-closed { background: #6c757d; color: white; }

.alert-time { color: #666; font-size: 0.9rem; }

.alert-body { margin-bottom: 1rem; }
.alert-info { margin-bottom: 0.75rem; color: #333; }
.alert-info p { margin: 0.5rem 0 0; line-height: 1.5; }

.alert-actions { display: flex; gap: 0.75rem; padding-top: 1rem; border-top: 1px solid #eee; }

.status-update-form select, .status-update-form button, .delete-form button {
    padding: 0.5rem;
    border-radius: 6px;
    font-size: 0.9rem;
}

.update-btn { background: #667eea; color: white; border: none; cursor: pointer; }
.update-btn:hover { background: #5a67d8; }

.delete-btn { background: #dc3545; color: white; border: none; cursor: pointer; }
.delete-btn:hover { background: #b02a37; }

.btn-back { display: inline-block; margin-top: 1.5rem; padding: 0.75rem 1.5rem; background: #6c757d; color: white; border-radius: 6px; text-decoration: none; }
.btn-back:hover { background: #5a6268; }

.no-alerts { text-align: center; padding: 3rem; background: white; border-radius: 10px; color: #666; }

@media (max-width: 768px) {
    .alert-header { flex-direction: column; align-items: flex-start; }
    .alert-actions { flex-direction: column; gap: 0.5rem; }
}
</style>

<?php include 'includes/footer.php'; ?>
