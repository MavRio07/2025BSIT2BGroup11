<?php
include 'config.php';

if (isset($_POST['add'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $age = $_POST['age'];

    if (!empty($name) && !empty($email) && !empty($age)) {
        $stmt = $conn->prepare("INSERT INTO users (name, email, age) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $name, $email, $age);
        $stmt->execute();
        echo "<p style='color:green;'>✅ New record added successfully!</p>";
    } else {
        echo "<p style='color:red;'>⚠️ Please fill out all fields!</p>";
    }
}

if (isset($_POST['delete_all'])) {
    $conn->query("DELETE FROM users");
    $conn->query("ALTER TABLE users AUTO_INCREMENT = 1");
    header("Location: index.php");
    exit();
}

