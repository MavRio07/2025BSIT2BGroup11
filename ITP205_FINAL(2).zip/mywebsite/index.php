<?php
// DATABASE CONNECTION
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mywebsite_db";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// ADD RECORD
if(isset($_POST['add'])){
  $stmt = $conn->prepare("INSERT INTO users (name, email, age) VALUES (?, ?, ?)");
  $stmt->bind_param("ssi", $_POST['name'], $_POST['email'], $_POST['age']);
  $stmt->execute();
  echo "<p style='color:green;'>✅ Added successfully!</p>";
  $stmt->close();
}

// UPDATE RECORD
if(isset($_POST['update'])){
  $stmt = $conn->prepare("UPDATE users SET name=?, email=?, age=? WHERE id=?");
  $stmt->bind_param("ssii", $_POST['name'], $_POST['email'], $_POST['age'], $_POST['id']);
  $stmt->execute();
  echo "<p style='color:blue;'>🔄 Updated successfully!</p>";
  $stmt->close();
}

// DELETE RECORD
if(isset($_POST['delete'])){
  $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
  $stmt->bind_param("i", $_POST['id']);
  $stmt->execute();
  echo "<p style='color:red;'>🗑️ Deleted successfully!</p>";
  $stmt->close();
}

// ✅ RESET AUTO_INCREMENT TO 1 WHEN TABLE IS EMPTY
$countResult = $conn->query("SELECT COUNT(*) AS count FROM users");
$countRow = $countResult->fetch_assoc();
if ($countRow['count'] == 0) {
  $conn->query("ALTER TABLE users AUTO_INCREMENT = 1");
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>PHP CRUD (One Page)</title>
  <style>
    body { font-family: Arial; margin: 40px; background: #f5f5f5; }
    h2 { color: #333; }
    form { background: white; padding: 20px; border-radius: 10px; margin-bottom: 30px; }
    input { margin: 5px; padding: 8px; }
    table { border-collapse: collapse; width: 100%; background: white; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
    th { background: #333; color: white; }
  </style>
</head>
<body>

<h2>Add New User</h2>
<form method="POST">
  Name: <input type="text" name="name" required>
  Email: <input type="email" name="email" required>
  Age: <input type="number" name="age" required>
  <input type="submit" name="add" value="Add">
</form>

<h2>Update User</h2>
<form method="POST">
  ID: <input type="number" name="id" required>
  New Name: <input type="text" name="name" required>
  New Email: <input type="email" name="email" required>
  New Age: <input type="number" name="age" required>
  <input type="submit" name="update" value="Update">
</form>

<h2>Delete User</h2>
<form method="POST">
  ID: <input type="number" name="id" required>
  <input type="submit" name="delete" value="Delete">
</form>

<h2>All Users</h2>
<table>
  <tr><th>ID</th><th>Name</th><th>Email</th><th>Age</th></tr>
  <?php
    $result = $conn->query("SELECT * FROM users ORDER BY id DESC");
    while($row = $result->fetch_assoc()){
      echo "<tr>
              <td>{$row['ID']}</td>
              <td>{$row['Name']}</td>
              <td>{$row['Email']}</td>
              <td>{$row['Age']}</td>
            </tr>";
    }
  ?>
</table>

</body>
</html>
