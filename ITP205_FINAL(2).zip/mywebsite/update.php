<?php
include 'config.php';

if(isset($_POST['update'])){
  $id = $_POST['id'];
  $name = $_POST['name'];
  $email = $_POST['email'];
  $age = $_POST['age'];

  $sql = "UPDATE users SET name='$name', email='$email', age='$age' WHERE id=$id";
  if ($conn->query($sql) === TRUE) {
    echo "Record updated!";
  } else {
    echo "Error updating record: " . $conn->error;
  }
}
?>

<form method="POST">
  ID to Update: <input type="number" name="id"><br>
  New Name: <input type="text" name="name"><br>
  New Email: <input type="text" name="email"><br>
  New Age: <input type="number" name="age"><br>
  <input type="submit" name="update" value="Update Record">
</form>
