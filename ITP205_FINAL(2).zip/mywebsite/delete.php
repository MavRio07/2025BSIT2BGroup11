<?php
include 'config.php';

if(isset($_POST['delete'])){
  $id = $_POST['id'] ?? null;

  if($id){
    $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    echo "<p style='color:red;'>🗑️ Deleted successfully!</p>";
    $stmt->close();
  } else {
    echo "<p style='color:red;'>⚠️ Please enter an ID to delete.</p>";
  }
}
