<?php
include 'config.php';

$result = $conn->query("SELECT * FROM users");

echo "<table border='1'>
<tr><th>ID</th><th>Name</th><th>Email</th><th>Age</th></tr>";

while($row = $result->fetch_assoc()) {
  echo "<tr>
  <td>".$row['id']."</td>
  <td>".$row['name']."</td>
  <td>".$row['email']."</td>
  <td>".$row['age']."</td>
  </tr>";
}
echo "</table>";
?>
